# -*- coding: utf-8 -*-
"script.helper"
import sys
import json
import xbmc
import xbmcaddon
import xbmcgui

#kodi-send -a 'RunScript("script.helper", passthrough)'
# add to keymap.xml
# <key id="XXX">RunScript("script.helper", passthrough)</key>


__addon__ = xbmcaddon.Addon()
__addonname__ = __addon__.getAddonInfo('name')
__addonid__ = __addon__.getAddonInfo('id')
__cwd__ = __addon__.getAddonInfo('path')
__icon__ = __addon__.getAddonInfo('path').decode('utf-8') + '/icon.png'
#i = int(1)


#datapath = xbmc.translatePath(ADDON.getAddonInfo('profile')).decode('utf-8')
#addonfolder = xbmc.translatePath(ADDON.getAddonInfo('path')).decode('utf-8')
#__debug__ = ADDON.getSetting('debug_mode')


def _execute(method, *args, **kwargs):
    if len(args) == 1:
        args = args[0]
        params = kwargs
        # Use kwargs for param=value style
    else:
        args = kwargs
    params = {}
    params['jsonrpc'] = '2.0'
    params['id'] = 1
    #i += 1
    params['method'] = method
    params['params'] = args

    cmd = json.dumps(params)
    #_log('RPC: execute %s'%(cmd))
    res = xbmc.executeJSONRPC(cmd)
    #_log('RPC: result %s'%(res))
    ret = json.loads(str(res))
    if 'error' in ret:
        _log('RPC ERROR: %s'%(ret['error']))
        return None
    return ret['result']

def _log(message):
    xbmc.log(msg='%s: %s' % (__addonid__, message), level=xbmc.LOGNOTICE)

def _passthrough():
    ret = _execute('Settings.GetSettingValue', {'setting':'audiooutput.passthrough'})
    passthrough = not ret['value']
    ret = _execute('Settings.SetSettingValue', {'setting':'audiooutput.passthrough','value':passthrough})
    #_log('RPC: result %s'%(ret))
    if passthrough:
        msg = 'enabled'
    else:
        msg = 'disabled'
    _log('RPC: Passthrough %s'%(msg))
    #xbmc.executebuiltin('Notification(%s, "Passthrough: %s", 3, %s)'%(__addonname__, msg, __icon__))
    xbmcgui.Dialog().notification(__addonname__, 'Passthrough: %s'%msg, __icon__, 3000)

def _main():
    args = len(sys.argv)

    cmd = None
    data = None
    if args > 1:
        cmd = sys.argv[1]
        if args > 2:
            data = sys.argv[2]
    if cmd == 'passthrough':
        _passthrough()
    else:
        _log('cmd=%s, data=%s'%(cmd, data))

if __name__ == '__main__':
    _main()
